const express = require("express");
const {
  isVoter,
  loginVoter,
  logoutVoter,
} = require("../controllers/AuthController.js");
const {
  getCandidates,
  getCandidateById,
} = require("../controllers/CandidatesController.js");
const { verifyVoter } = require("../middlewares/AuthMiddleware.js");
const { updateVoterCandidate } = require("../controllers/VotersController.js");
const router = express.Router();
router.get("/", isVoter);
router.post("/", loginVoter);
router.delete("/", logoutVoter);
router.get("/calon/", verifyVoter, getCandidates);
router.get("/calon/:id", verifyVoter, getCandidateById);
router.patch("/calon/:candidateId", verifyVoter, updateVoterCandidate);
module.exports = router;
